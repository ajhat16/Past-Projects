/* CSCI-4061 Fall 2022 – Project #4
 * Group Member #1: Alex Hatoum hatou003
 * Group Member #2: Chase Wilson wils2538
 * Group Member #3: Abdullah Meneese menee008 */
 
# Overview
I (Alex Hatoum) did most of the work yet again. It would probably be best to read my last write-up for project 3 for details because it was practically the same experience as that.
